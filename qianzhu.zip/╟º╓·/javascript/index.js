//全屏滚动
        function scroll(){
        var index=0;
        var event=$('.list-inline>li').each;
        var h=$(window).height();
        var len=$("section").length;
        $("section").height($(window).height()); 
        var lastTime=new Date();
        $(document).mousewheel(function(event,delta,deltaX,deltaY){
        if(new Date()-lastTime>1000){
        lastTime=new Date();
        if(delta==-1){
        index++;
        this.index=event;
        if(index<=len-1){
        this.index=event;
        var s=$('.list-inline li').eq(index).position().left;
        $('#slide').stop(true).animate({left:s+'px'},500);
        $("body,html").animate({"scrollTop":index*h},1000);
         $('.header').css({backgroundColor:'#66686A',opacity:'0.8'});
        $('.list-inline li').css({'font-size':'16px'});
        }else if(index==len-1){
        return;
        }
        }else if(delta==1){
        if(index>0){
         this.index=event;
        index--;
        $('#slide').stop(true).animate({left:($('.list-inline>li').eq(index).position().left+5+'px')},300);
          $('.header').css({backgroundColor:'#66686A',opacity:'0.8'});
        $("body,html").animate({"scrollTop":index*h},1000);
        }else if(index==0){
         $('.header').css({backgroundColor:''})
        $('.list-inline>li').css({'font-size':'22px'});
        }else{
        return;
        }
        }
        }
        })
  $('.list-inline>li').each(function(event){
         this.index=event;
        var h=$(window).height();
        $(this).click(function(){
        $("body,html").animate({"scrollTop":event*h},1000);
        $('.header').css({backgroundColor:'red'})
        if(event==0){
        $('.list-inline>li').css({'font-size':'22px'});
        $('.header').css({backgroundColor:''})

        }else{
        $('.list-inline>li').css({'font-size':'16px'});
        $('.header').css({backgroundColor:'#66686A',opacity:'0.8'})
        }

        })
        })
        }
        window.onresize=function(){
        scroll();
        }
       scroll();
        $('.list-inline li a').each(function(e){
        $(this).hover(function(){
        $('#slide').css({'width':s-3+'px'});
        var s=$('.list-inline li').width();
        $('#slide').stop(true).animate({left:($('.list-inline li').eq(e).position().left+'px')},300);
        })
        })
//菜单滑动

//轮播效果
        var  circle=$('.point_btn');
        var prop=$('.prop');
        var li=prop.children();
        var time;
        var num=0;
        var Width=$('.business').outerWidth(true);
        function auto(){
        time=setInterval(function(){
        num++;
        if(num>=li.length){
        prop.animate({marginLeft:'-num*Width'},1000,function(){
        prop.css('marginLeft','0px');
        num=0;
        circle.each(function(index,ele){
        $(ele).css('background','#fff');
        })
        circle.eq(num).css('background','#00dfb9');
        })
        }else{
        prop.animate({marginLeft:-num*Width},500);
        circle.each(function(index,ele){
        $(ele).css('background','#fff');
        })
        circle.eq(num).css('background','#00dfb9');
        }
        },5000)
        }
        var circle=$('.circle');
        circle.eq(0).css('background','#00dfb9')
        circle.mouseover(function(){
        prop.animate({'marginLeft':-$(this).index()*Width},500,'linear');
        circle.each(function(index,ele){
        $(ele).css('background','#fff');
        })
        circle.eq($(this).index()).css('background','#00dfb9');
        nums=$(this).index();
        })
        circle.hover(function(){
        clearInterval(time);
        },function(){
        auto();
        })
        auto();
        window.onresize=function(){
        auto();
        }
        window.onload=function(){
        $('.box .left').animate({left:'-20px'},500);
        $('.box .right').animate({right:'-20px'},500);
        $('.prop li').eq(2).find('.box3').animate({top:'300px'},500);
        }
//轮播效果

// 第二栏开始
        var clip_li=$('#point>li')
        var cl=$('.cl');
        var cr=$('.cr');
        var clip_i=$('#point>li>i');
        var clip_p=$('#point>li>p');
        var clip_s=$('#point>li>strong');

        clip_li.hover(function(){
        var index=$(this).index();
        cl.eq(index).css({'clip':'rect(0px,156px,-10px,78px)','transition':'all .5s ease-in-out 0s'});
        cr.eq(index).css({'clip':'rect(156px,78px,156px,0px)','transition':'all .5s ease-in-out 0s'});
        clip_li.eq(index).css({'backgroundPosition':'0px 0px','transition':'all .5s ease-in-out 0.3s'});
        clip_p.eq(index).css({'top':'20px','transition':'all .5s ease-in-out 0.3s'});
        clip_s.eq(index).css({'color':'#fff','transition':'all .5s ease-in-out 0.3s'})
        if(index==0){
        clip_i.eq(index).css({'backgroundPosition':'-167px -357px','transition':'all .5s ease-in-out 0.3s'})
        }else if(index==1){
        clip_i.eq(index).css({'backgroundPosition':'-338px -291px','transition':'all .5s ease-in-out 0.3s'})
        }else if(index==2){
        clip_i.eq(index).css({'backgroundPosition':'-328px -362px','transition':'all .5s ease-in-out 0.3s'})
        }else if(index==3){
        clip_i.eq(index).css({'backgroundPosition':'-168px -439px','transition':'all .5s ease-in-out 0.3s'})
        }else if(index==4){
        clip_i.eq(index).css({'backgroundPosition':'-335px -439px','transition':'all .5s ease-in-out 0.3s'})
        }
        },function(){
        cl.css({'clip':'rect(0px,156px,156px,78px)','transition':'all .5s ease-in-out 0s'});
        cr.css({'clip':'rect(0px,78px,156px,0px)','transition':'all .5s ease-in-out 0s'});
        clip_li.css({'backgroundPosition':'0px 400px','transition':'all 0s ease-in-out 0s'});
        clip_p.css({'top':'200px','transition':'all 0s ease-in-out 0s'});
        clip_s.css({'color':'#333','transition':'all 0s ease-in-out 0s'});
        clip_i.eq(0).css({'backgroundPosition':'-245px -357px','transition':'all 0s ease-in-out 0s'});
        clip_i.eq(1).css({'backgroundPosition':'-416px -291px','transition':'all 0s ease-in-out 0s'});
        clip_i.eq(2).css({'backgroundPosition':'-415px -362px','transition':'all 0s ease-in-out 0s'});
        clip_i.eq(3).css({'backgroundPosition':'-244px -439px','transition':'all 0s ease-in-out 0s'});
        clip_i.eq(4).css({'backgroundPosition':'-420px -439px','transition':'all 0s ease-in-out 0s'});

	})
// 第二栏结束
// 第三栏开始
        $(".box_shade").each(function(index){
        $('.box_shade').eq(index).hover(function(){
        $(this).find('.shade_dowm').stop(true).animate({top:'200px'},300);
        $(this).find('.shade_up').stop(true).animate({top:'0px'},300);
        $(this).find('.shade_content>p').css({color:'#fff'})
        let flage=false;
        },function(){

        $(this).find('.shade_dowm').stop(true).animate({top:'300px'},300);
        $(this).find('.shade_up').stop(true).animate({top:'-200px'},300);
        $(this).find('.shade_content>p').css({color:'#999999'})
        });
        })
//第三栏结束
//第四栏开始
        var mask=document.getElementById('mask');
        var fixBox=document.getElementById('fix-box');
        fixBox.addEventListener('mouseover',function(event){
        mask.style.display="block";
        mask.style.top=event.target.offsetTop+'px';
        mask.style.left=event.target.offsetLeft+'px';
        },false)
        fixBox.addEventListener('mouseleave', function () {
        mask.style.display = "none"
        }, false);
//第四栏结束
//第五栏开始
/*无*/
//第五栏结束

//第六栏开始
/*无*/
//第六栏结束
//第七栏开始
        var option_li=$('.menu2>li');
        var bg=$('#bg');
        var option_box=$('.option_box');
        var font_li=$('.option_box>li');
        var num2=0;
        option_li.eq(0).css('color','#fff');
        var o=setInterval(Option,8000);
        function Option(){
        num2++;
        if(num2>font_li.length-2){
        option_box.stop(true).animate({'left':-num2*480+'px'},500,'linear',function(){
        option_box.css('left','0px');
        num2=0;
        });

        bg.stop(true).animate({'top':'0px'},20,function(){
        option_li.each(function(index,ele){
        $(ele).css('color','#888');
        })
        option_li.eq(0).css('color','#fff');
        });

        }else{
        option_box.stop(true).animate({'left':-num2*480+'px'},500,'linear');
        bg.stop(true).animate({'top':num2*42+'px'},20,function(){
        option_li.each(function(index,ele){
        $(ele).css('color','#888');
        })
        option_li.eq(num2).css('color','#fff');
        });
        }
        }
        option_li.hover(function(){
        clearInterval(o);
        var index=$(this).index();
        option_box.animate({'left':-index*480+'px'},500,'linear');
        bg.stop(true).animate({'top':index*42+'px'},20,function(){
        option_li.each(function(index,ele){
        $(ele).css('color','#888');
        })
        option_li.eq(index).css('color','#fff');
        });
        num2=index;
        },function(){
        o=setInterval(Option,8000);
        })
//第七栏结束
//第八栏开始
//第九栏结束
    //侧边栏
	var switchs=$('.switch');
	var switchs_a=switchs.find('a');
	var option=$('.sidebar_option');
	var switchs_flag=true;
	switchs.click(function(){

		if(switchs_flag){
			option.animate({'left':'100px'},500,'linear');
			switchs_a.css('backgroundPosition','-32px -640px');
			switchs_flag=false;
		}else{
			option.animate({'left':'0px'},500,'linear');
			switchs_a.css('backgroundPosition','0px -640px');
			switchs_flag=true;
		}
		
	})

    //侧边栏滑动效果
    var z=1;
	var qq=$('.qq');
	qq.hover(function(){
		z++;
		qq.css('zIndex',z);	
		if(!$('.qq_box').is(':animated')){
			$('.qq_box').animate({'left':'-156'},500);
		}
	},function(){
			$('.qq_box').animate({'left':'60'},20)
	})

	var telephone=$('.telephone');
	telephone.hover(function(){
		z++;
		telephone.css('zIndex',z);	
		if(!$('.phone_box').is(':animated')){
			$('.phone_box').animate({'left':'-241'},500)
		}
	},function(){
			$('.phone_box').animate({'left':'60'},20)
	})

	var wechat=$('.wechat');
	wechat.hover(function(){
		z++;
		wechat.css('zIndex',z);	 
		if(!$('.wechat_box').is(':animated')){
			$('.wechat_box').animate({'left':'-159'},500)
		}
	},function(){
			$('.wechat_box').animate({'left':'60'},20)
	})



	//up点击
	var up=$('.up');
	up.click(function(){
		if(flags){
   			flags=false;;'';
			num--;
			z++;

			if(num<0){
				num=0; 
			}else{
				box.eq(num).css({'top':-height,'zIndex':z});
				box.eq(num).animate({'top':0},function(){
					flags=true;
					flag=true;
				})
			}

			OverallSituation();

			btn_a.each(function(index,ele){
				$(ele).css('color','#ccc');
			})
			btn_a.eq(num).css('color','#00dfb9');
			border.css('left',num*84+11+'px');
		}
	})

	//down点击
	var down=$('.down');
	down.click(function(){
		if(flag){
			flag=false;
			num++;
			z++;

			if(num>box.length-1){
				num=box.length-1;
			}else{
				box.eq(num).css({'top':height,'zIndex':z});
				box.eq(num).animate({'top':0},function(){
					flags=true;
					flag=true;
				})
			}
			OverallSituation();

			btn_a.each(function(index,ele){
				$(ele).css('color','#ccc');
			})
			btn_a.eq(num).css('color','#00dfb9');
			border.css('left',num*84+11+'px');
				
		}

	})





















// function auto(){
// 	var k=0;
// var W=$('.max_box').width();
// var w=$('.max_box li').width();
// var Time=setInterval(function(){
//    k++;
// var s=$('.max_box li').length;
// $('.max_box').animate({left:-k*w+'px'},500,function(){
// 	if(k==s){
// 	 $(".max_box li").first().appendTo($(this));
// 	 $(this).css({left:'0px'},500);
// 		k=-1;
// 	}
// });

// },3000)
// }
// auto();



